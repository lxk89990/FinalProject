from flask import Flask ,request ,render_template
import pickle
import numpy as np


app = Flask(__name__)


with open('d_tree.pickle','rb') as f: 
    model = pickle.load(f)

@app.route("/")
def home():
    return render_template("home.html")

# Rainfall', 'Sunshine', 'WindGustSpeed', 'Humidity9am', 'Humidity3pm', 'Pressure9am', 'Pressure3pm', 'Cloud9am', 'Cloud3pm', 'RainToday'

@app.route("/rainFall",methods=['post'])
def rainFall():
    Rainfall = request.form.get("Rainfall")
    Sunshine = request.form.get("Sunshine")
    WindGustSpeed = request.form.get("WindGustSpeed")
    Humidity9am = request.form.get("Humidity9am")
    Humidity3pm = request.form.get("Humidity3pm")
    Pressure9am = request.form.get("Pressure9am")
    Pressure3pm = request.form.get("Pressure3pm")
    Cloud9am = request.form.get("Cloud9am")
    Cloud3pm = request.form.get("Cloud3pm")
    RainToday = request.form.get("RainToday")
    values = [[Rainfall,Sunshine,WindGustSpeed,Humidity9am,Humidity3pm,Pressure9am,Pressure3pm,Cloud9am,Cloud3pm,RainToday]]
    input = np.array(values)
    result = model.predict(input)
    if result == 0:
        return render_template("msg.html",msg='No Rain Tomorrow',color='text-primary')
        # print('No rain tomorrow')
    else:
        return render_template("msg.html", msg='You can expect rainfall tomorrow',color='text-warning')
        # print('You can expect rainfall tomorrow')






app.run(debug=True)